RPC Port: 27817
Network Port: 27816